# injuryimpact

Premier League injury data pipeline and Impact Score engine, with a static club dashboard.
Estimates only. **Not medical advice.**

## Quick start
```bash
pip install -e ".[dev]"
pytest
python -m injuryimpact.site        # writes docs/index.html
```

## Automatic data (API-Football)
```bash
cp .env.example .env               # add API_FOOTBALL_KEY
python -m injuryimpact.adapters.api_football               # injuries only, 2 calls
python -m injuryimpact.adapters.api_football --with-stats  # + team and injured-player stats, ~25-50 calls
python -m injuryimpact.site
```
The free tier allows 100 calls/day; runs stop at 90%. Usage is tracked in `data/.api_usage.json`.
Each refresh rewrites `data/injuries.csv`: players no longer listed are dropped, and the manual `rating`
and `start_date` columns are kept. API-Football lists injuries per fixture, so the start date is the first
missed fixture of the current run, an approximation. For a scheduled refresh on GitHub, add the repo secret
`API_FOOTBALL_KEY`; `.github/workflows/refresh.yml` updates the data and page every 6 hours.

## Put real data in by hand
Edit the CSVs in `data/` (all clubs use the ids from `config/clubs.yaml`):

| file | columns |
|---|---|
| `injuries.csv` | club, player, position, injury_type, status, start_date, date_of_birth, minutes, goals, assists, rating |
| `team_stats.csv` | club, matches_played, total_goals |
| `fixtures.csv` | kickoff (ISO UTC), home, away, difficulty_home, difficulty_away (0-1) |

Delete the `EXAMPLE_ROW_DELETE_ME` row first. `rating` is the manual 0-1 replacement gap (blank = default 0.5).
Each club's **one to watch** is its injured player with the highest Impact Score.

## Crests
Club crests are trademarked, so none are bundled. Add your own licensed files as
`docs/crests/<club-id>.svg` (paths are in `config/clubs.yaml`). Missing files fall back to a coloured badge.

## Before publishing
`config/recovery_ranges.csv` holds PLACEHOLDER ranges. Replace them with cited sources.

## GitHub Pages
Settings > Pages > Deploy from branch > `main` / `/docs`.
