from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone

import pytest

from injuryimpact.config import load_settings
from injuryimpact.impact import (FixtureView, compute_impact, fixture_difficulty, goal_contribution_share,
                                 minutes_share, replacement_gap)
from injuryimpact.types import RecoveryEstimate

S = load_settings()
CFG = S.impact
NOW = datetime(2026, 10, 22, 12, tzinfo=timezone.utc)
START = date(2026, 10, 15)                    # one week elapsed


@dataclass
class P:
    minutes: int = 0
    goals: int = 0
    assists: int = 0


@dataclass
class T:
    total_minutes_available: int = 900
    total_goals: int = 20


EST = RecoveryEstimate("hamstring", 2, 4, 8)   # remaining after 1 week: 1-7 weeks


def fx(days, home="A", away="B", dh=0.8, da=0.2, status="scheduled"):
    return FixtureView(NOW + timedelta(days=days), home, away, dh, da, status)


def run(**kw):
    args = dict(injury_id=1, club="A", player_stats=P(450, 5, 3), team_stats=T(), rating=0.7, estimate=EST,
                start_date=START, fixtures=[fx(3), fx(10, home="C", away="A", dh=0.4, da=0.6)], cfg=CFG,
                weights_version=S.weights_version, as_of=NOW)
    args.update(kw)
    return compute_impact(**args)


def test_normal_score_matches_hand_calculation():
    r = run()
    c = r.components
    assert c.minutes_share == pytest.approx(0.5)
    assert c.goal_contribution_share == pytest.approx(0.4)
    assert c.fixture_difficulty == pytest.approx((0.8 + 0.6) / 2)
    assert c.fixtures_in_window == 2 and not c.fixture_window_empty
    assert r.score == pytest.approx(10 * (0.4 * 0.5 + 0.3 * 0.4 + 0.2 * 0.7 + 0.1 * 0.7), abs=0.01)
    assert r.weights_version == S.weights_version


def test_score_within_scale():
    r = run(player_stats=P(900, 50, 50), team_stats=T(900, 20), rating=1.0, fixtures=[fx(2, dh=1.0)])
    assert r.score == pytest.approx(10.0)
    assert 0 <= run().score <= 10


# --- zero minutes ---------------------------------------------------------
def test_zero_minutes_no_division_error_and_flagged():
    r = run(player_stats=P(0, 0, 0))
    assert r.components.minutes_share == 0.0 and r.components.limited_data is True


def test_zero_team_minutes_flagged():
    assert minutes_share(P(100), T(0, 0)) == (0.0, True)


def test_missing_stats_flagged():
    r = run(player_stats=None, team_stats=None)
    assert r.components.limited_data and r.components.goal_contribution_share == 0.0


def test_minutes_share_capped_at_one():
    assert minutes_share(P(2000), T(900))[0] == 1.0


# --- zero goals -----------------------------------------------------------
def test_zero_goals_with_minutes_is_real_zero_not_limited():
    r = run(player_stats=P(900, 0, 0))
    assert r.components.goal_contribution_share == 0.0 and r.components.limited_data is False


def test_zero_goals_differs_from_zero_minutes():
    assert run(player_stats=P(900, 0, 0)).components.limited_data != run(player_stats=P(0)).components.limited_data


def test_team_with_no_goals():
    assert goal_contribution_share(P(900, 2, 1), T(900, 0)) == 0.0


def test_goal_share_capped_at_one():
    assert goal_contribution_share(P(900, 10, 10), T(900, 5)) == 1.0


# --- missing rating -------------------------------------------------------
def test_missing_rating_uses_default_and_flags():
    r = run(rating=None)
    assert r.components.replacement_gap == CFG.default_replacement_gap
    assert r.components.replacement_gap_defaulted is True


def test_given_rating_not_flagged():
    assert run(rating=0.0).components.replacement_gap_defaulted is False


@pytest.mark.parametrize("bad", [-0.1, 1.5])
def test_rating_out_of_range_rejected(bad):
    with pytest.raises(ValueError):
        replacement_gap(bad, 0.5)


# --- no fixtures in window ------------------------------------------------
def test_no_fixtures_neutral_and_flagged():
    r = run(fixtures=[])
    assert r.components.fixture_difficulty == CFG.neutral_fixture_difficulty
    assert r.components.fixture_window_empty and r.components.fixtures_in_window == 0


def test_fixtures_beyond_window_ignored():
    r = run(fixtures=[fx(60)])                 # remaining max is 7 weeks = 49 days
    assert r.components.fixture_window_empty


def test_past_and_other_club_and_unscheduled_and_missing_difficulty_ignored():
    fixtures = [fx(-2), fx(3, home="X", away="Y"), fx(3, status="postponed"), fx(3, dh=None)]
    assert run(fixtures=fixtures).components.fixture_window_empty


def test_home_and_away_difficulty_picked_by_side():
    assert fixture_difficulty("A", [fx(3)], as_of=NOW, window_weeks=2, neutral=0.5)[0] == 0.8
    assert fixture_difficulty("B", [fx(3)], as_of=NOW, window_weeks=2, neutral=0.5)[0] == 0.2


# --- recovery interaction -------------------------------------------------
def test_overdue_gives_empty_window_and_flag():
    r = run(start_date=date(2026, 8, 1))        # ~11 weeks elapsed > max 8
    c = r.components
    assert c.overdue and c.fixture_window_empty and c.fixture_difficulty == CFG.neutral_fixture_difficulty


def test_unknown_injury_type_no_estimate_neutral_window():
    r = run(estimate=None)
    assert r.components.fixture_window_empty and not r.components.overdue


def test_short_remaining_window_excludes_later_fixtures():
    r = run(start_date=date(2026, 9, 24), fixtures=[fx(3), fx(30)])   # ~4 weeks elapsed, 4 left
    assert r.components.fixtures_in_window == 1


# --- validation / auditability -------------------------------------------
def test_naive_datetimes_rejected():
    with pytest.raises(ValueError):
        run(as_of=datetime(2026, 10, 22))
    with pytest.raises(ValueError):
        run(fixtures=[FixtureView(datetime(2026, 10, 25), "A", "B", 0.5, 0.5)])


def test_negative_stats_rejected():
    with pytest.raises(ValueError):
        run(player_stats=P(-1))


def test_components_serialisable_and_weights_recorded():
    d = run().components.to_dict()
    assert d["weights"] == CFG.weights and "limited_data" in d and "overdue" in d
