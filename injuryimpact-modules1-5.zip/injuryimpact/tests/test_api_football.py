import csv
import json
from datetime import datetime, timezone

import pytest

from injuryimpact.adapters.api_football import (ApiFootballClient, ApiFootballError, BudgetExceeded, BudgetTracker,
                                                ClubResolver, parse_injuries, parse_player_stats, parse_team_stats,
                                                parse_teams, run, write_injuries_csv)

NOW = datetime(2026, 10, 22, 12, tzinfo=timezone.utc)
R = ClubResolver.from_config()


def entry(pid, name, team, tid, typ, reason, date):
    ts = int(datetime.fromisoformat(date).timestamp())
    return {"player": {"id": pid, "name": name, "type": typ, "reason": reason},
            "team": {"id": tid, "name": team},
            "fixture": {"id": 1, "date": date, "timestamp": ts}}


INJ = {"errors": [], "response": [
    entry(1, "Star One", "Arsenal", 42, "Missing Fixture", "Hamstring Injury", "2026-10-03T14:00:00+00:00"),
    entry(1, "Star One", "Arsenal", 42, "Missing Fixture", "Hamstring Injury", "2026-10-17T14:00:00+00:00"),
    entry(1, "Star One", "Arsenal", 42, "Missing Fixture", "Hamstring Injury", "2026-10-24T14:00:00+00:00"),
    entry(2, "Healed Guy", "Chelsea", 49, "Missing Fixture", "Knee Injury", "2026-09-01T14:00:00+00:00"),   # old
    entry(3, "Maybe Man", "Man City", 50, "Questionable", "Calf Injury", "2026-10-24T14:00:00+00:00"),
    entry(4, "Other League", "Real Madrid", 541, "Missing Fixture", "Illness", "2026-10-24T14:00:00+00:00"),
    entry(5, "Odd Status", "Tottenham", 47, "Suspended?", "Illness", "2026-10-24T14:00:00+00:00"),
    entry(6, "Reinjured", "Liverpool", 40, "Missing Fixture", "Calf Injury", "2026-08-01T14:00:00+00:00"),
    entry(6, "Reinjured", "Liverpool", 40, "Missing Fixture", "Calf Injury", "2026-10-17T14:00:00+00:00"),
    entry(6, "Reinjured", "Liverpool", 40, "Missing Fixture", "Calf Injury", "2026-10-24T14:00:00+00:00"),
]}


def parse(payload=INJ):
    return parse_injuries(payload, as_of=NOW, resolver=R, source_url="http://x")


def test_collapses_per_fixture_entries_to_one_current_injury_per_player():
    res = parse()
    names = [p.norm.player_name for p in res.injuries]
    assert sorted(names) == ["Maybe Man", "Reinjured", "Star One"]


def test_old_entries_dropped_and_unknown_club_reported():
    res = parse()
    assert "Healed Guy" not in [p.norm.player_name for p in res.injuries]
    assert res.unknown_clubs == {"Real Madrid"}


def test_status_mapping_and_review():
    res = parse()
    by = {p.norm.player_name: p for p in res.injuries}
    assert by["Star One"].norm.status.value == "out" and by["Maybe Man"].norm.status.value == "doubtful"
    assert any("Odd Status" in m for m in res.needs_review)
    assert "Odd Status" not in by


def test_alias_resolution():
    assert R.resolve("Man City") == "man-city" and R.resolve("Tottenham") == "tottenham"
    assert R.resolve("Brighton & Hove Albion") == "brighton" and R.resolve("Nottingham Forest") == "nottm-forest"
    assert R.resolve("Real Madrid") is None


def test_start_date_is_first_fixture_of_unbroken_run():
    by = {p.norm.player_name: p.norm for p in parse().injuries}
    assert by["Star One"].start_date.isoformat() == "2026-10-03"
    assert by["Reinjured"].start_date.isoformat() == "2026-10-17"      # 2.5 month gap breaks the run


def test_parse_teams_and_stats():
    teams = parse_teams({"response": [{"team": {"id": 42, "name": "Arsenal"}}, {"team": {"id": 9, "name": "Nope"}}]}, R)
    assert teams == {"42": "arsenal"}
    assert parse_team_stats({"response": {"fixtures": {"played": {"total": 9}},
                                          "goals": {"for": {"total": {"total": 21}}}}}) == (9, 21)
    assert parse_team_stats({"response": []}) is None


def test_player_stats_sum_league_only_and_handle_nulls():
    payload = {"response": [{"player": {"birth": {"date": "1999-02-03"}}, "statistics": [
        {"league": {"id": 39}, "games": {"minutes": 600, "position": "Attacker"}, "goals": {"total": 4, "assists": None}},
        {"league": {"id": 2}, "games": {"minutes": 90, "position": "Attacker"}, "goals": {"total": 9, "assists": 9}},
        {"league": {"id": 39}, "games": {"minutes": None}, "goals": {"total": None, "assists": 2}}]}]}
    got = parse_player_stats(payload, 39)
    assert got == {"minutes": 600, "goals": 4, "assists": 2, "position": "FWD", "date_of_birth": "1999-02-03"}
    assert parse_player_stats({"response": []}, 39) is None
    assert parse_player_stats({"response": [{"statistics": [{"league": {"id": 2}}]}]}, 39) is None


# --- client, budget, CSV --------------------------------------------------
class Resp:
    def __init__(self, data, status=200):
        self._d, self.status_code = data, status

    def json(self):
        return self._d


class FakeSession:
    def __init__(self, routes):
        self.routes, self.calls = routes, []

    def get(self, url, params=None, headers=None, timeout=None):
        self.calls.append((url, params, headers))
        r = self.routes[url.rsplit("/v3/", 1)[-1] if "/v3/" in url else url.split("/", 3)[-1]]
        return r if isinstance(r, Resp) else Resp(r)


def make_client(tmp_path, routes, limit=100):
    return ApiFootballClient("SECRETKEY", "https://v3.test", BudgetTracker(tmp_path / "u.json", limit, 0.9),
                             session=FakeSession(routes))


def test_client_sends_key_header_and_counts_calls(tmp_path):
    c = make_client(tmp_path, {"injuries": {"errors": [], "response": []}})
    c.get("injuries", {"league": 39})
    assert c.session.calls[0][2] == {"x-apisports-key": "SECRETKEY"} and c.budget.calls_today() == 1


def test_api_errors_raise_without_leaking_key(tmp_path):
    c = make_client(tmp_path, {"injuries": {"errors": {"token": "bad"}, "response": []}})
    with pytest.raises(ApiFootballError) as e:
        c.get("injuries")
    assert "SECRETKEY" not in str(e.value)
    c2 = make_client(tmp_path, {"injuries": Resp({}, 500)})
    with pytest.raises(ApiFootballError):
        c2.get("injuries")


def test_budget_stops_at_ninety_percent(tmp_path):
    c = make_client(tmp_path, {"injuries": {"errors": [], "response": []}}, limit=10)
    for _ in range(9):
        c.get("injuries")
    with pytest.raises(BudgetExceeded):
        c.get("injuries")


def test_csv_preserves_manual_rating_and_drops_recovered(tmp_path):
    path = tmp_path / "injuries.csv"
    path.write_text("club,player,position,injury_type,status,start_date,date_of_birth,minutes,goals,assists,rating\n"
                    "arsenal,Star One,FWD,hamstring,out,2026-09-30,1995-01-01,10,0,0,0.9\n"
                    "chelsea,Recovered,DEF,calf,out,2026-09-01,,0,0,0,0.3\n", encoding="utf-8")
    parsed = parse().injuries
    write_injuries_csv(path, parsed, {"1": {"minutes": 700, "goals": 5, "assists": 2, "position": "FWD",
                                            "date_of_birth": "1995-01-01"}})
    rows = {r["player"]: r for r in csv.DictReader(open(path, encoding="utf-8"))}
    assert "Recovered" not in rows and len(rows) == 3
    s = rows["Star One"]
    assert s["rating"] == "0.9" and s["start_date"] == "2026-09-30" and s["minutes"] == "700"
    assert rows["Maybe Man"]["rating"] == ""


def test_end_to_end_run_feeds_report(tmp_path):
    from injuryimpact.report import build_report
    routes = {"injuries": INJ,
              "teams": {"errors": [], "response": [{"team": {"id": 42, "name": "Arsenal"}}]},
              "teams/statistics": {"errors": [], "response": {"fixtures": {"played": {"total": 9}},
                                                              "goals": {"for": {"total": {"total": 18}}}}},
              "players": {"errors": [], "response": [{"player": {"birth": {"date": "1995-01-01"}}, "statistics": [
                  {"league": {"id": 39}, "games": {"minutes": 700, "position": "Attacker"},
                   "goals": {"total": 6, "assists": 2}}]}]}}
    client = make_client(tmp_path, routes)
    out = run(client, tmp_path, league_id=39, season=2026, resolver=R, with_stats=True, as_of=NOW, log=lambda *a: None)
    assert out["injuries"] == 3 and out["calls"] == 1 + 1 + 1 + 3
    by = {c.id: c for c in build_report(tmp_path, as_of=NOW)}
    p = by["arsenal"].players[0]
    assert p.name == "Star One" and p.position == "FWD" and p.score > 0 and p.watch
    assert any("Real Madrid" in w for w in out["warnings"])


def test_run_stops_gracefully_when_budget_hit(tmp_path):
    routes = {"injuries": INJ, "teams": {"errors": [], "response": [{"team": {"id": 42, "name": "Arsenal"}}]},
              "teams/statistics": {"errors": [], "response": {}}}
    client = make_client(tmp_path, routes, limit=3)          # allowed = 2 calls
    out = run(client, tmp_path, league_id=39, season=2026, resolver=R, with_stats=True, as_of=NOW, log=lambda *a: None)
    assert out["injuries"] == 3 and any("stopped early" in w for w in out["warnings"])
