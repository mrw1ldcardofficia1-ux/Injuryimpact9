from datetime import date

import pytest

from injuryimpact.config import load_settings
from injuryimpact.recovery import (RecoveryRangeData, estimate_recovery, estimated_return_dates, full_years,
                                   load_recovery_ranges_csv, remaining_range)

CFG = load_settings().recovery            # age>30 x1.15, same injury within 365d x1.25
RANGES = {
    "hamstring": RecoveryRangeData("hamstring", 2, 4, 8, 0.17, "test"),
    "acl": RecoveryRangeData("acl", 36, 40, 52, 0.06, "test"),
}
TODAY = date(2026, 10, 22)


def est(**kw):
    return estimate_recovery("hamstring", RANGES, CFG, as_of=TODAY, **kw)


def test_base_range_no_modifiers():
    e = est()
    assert (e.min_weeks, e.median_weeks, e.max_weeks) == (2, 4, 8)
    assert e.modifiers_applied == () and e.reinjury_risk == 0.17


def test_always_labelled_estimate():
    e = est()
    assert e.is_estimate is True and "not medical advice" in e.disclaimer.lower()
    assert e.to_dict()["is_estimate"] is True


def test_unknown_or_missing_type_gives_none():
    assert estimate_recovery("mystery", RANGES, CFG, as_of=TODAY) is None
    assert estimate_recovery(None, RANGES, CFG, as_of=TODAY) is None


def test_age_modifier_applies_strictly_over_threshold():
    assert est(date_of_birth=date(1996, 10, 22)).modifiers_applied == ()          # exactly 30
    e = est(date_of_birth=date(1995, 10, 21))                                      # 31
    assert e.modifiers_applied and e.max_weeks == pytest.approx(9.2)
    assert e.min_weeks == pytest.approx(2.3)


def test_missing_dob_means_no_age_modifier():
    assert est(date_of_birth=None).modifiers_applied == ()


def test_reinjury_window_boundaries():
    assert est(previous_same_injury_dates=[date(2026, 1, 1)]).max_weeks == pytest.approx(10.0)
    assert est(previous_same_injury_dates=[date(2025, 10, 22)]).max_weeks == pytest.approx(10.0)   # 365d, inside
    assert est(previous_same_injury_dates=[date(2025, 10, 21)]).modifiers_applied == ()           # 366d, outside
    assert est(previous_same_injury_dates=[TODAY]).modifiers_applied == ()                         # same day = current


def test_reinjury_applied_once_even_with_many_priors():
    e = est(previous_same_injury_dates=[date(2026, 1, 1), date(2026, 5, 1), date(2026, 8, 1)])
    assert e.max_weeks == pytest.approx(10.0)


def test_modifiers_stack():
    e = est(date_of_birth=date(1990, 1, 1), previous_same_injury_dates=[date(2026, 6, 1)])
    assert len(e.modifiers_applied) == 2
    assert e.max_weeks == pytest.approx(11.5)          # 8 * 1.15 * 1.25 = 11.5


def test_full_years():
    assert full_years(date(2000, 10, 23), date(2026, 10, 22)) == 25
    assert full_years(date(2000, 10, 22), date(2026, 10, 22)) == 26


def test_remaining_range_and_overdue():
    e = est()
    r = remaining_range(e, date(2026, 10, 8), TODAY)           # 2 weeks elapsed
    assert (r.min_weeks, r.max_weeks, r.overdue) == (0.0, 6.0, False)
    late = remaining_range(e, date(2026, 8, 1), TODAY)
    assert (late.min_weeks, late.max_weeks, late.overdue) == (0.0, 0.0, True)
    assert remaining_range(e, None, TODAY).max_weeks == 8
    assert remaining_range(e, date(2026, 11, 1), TODAY).max_weeks == 8      # future start: nothing elapsed


def test_estimated_return_dates():
    lo, hi = estimated_return_dates(date(2026, 10, 1), est())
    assert (lo, hi) == (date(2026, 10, 15), date(2026, 11, 26))


def test_range_data_validation():
    with pytest.raises(ValueError):
        RecoveryRangeData("x", 5, 3, 8, 0.1, "bad order")
    with pytest.raises(ValueError):
        RecoveryRangeData("x", 1, 2, 3, 1.5, "bad risk")


def test_csv_loader(tmp_path):
    good = tmp_path / "ok.csv"
    good.write_text("injury_type,min_weeks,median_weeks,max_weeks,reinjury_risk,source_note\n"
                    "Hamstring,2,4,8,0.17,note\n")
    assert load_recovery_ranges_csv(good)["hamstring"].median_weeks == 4
    bad = tmp_path / "bad.csv"
    bad.write_text("injury_type,min_weeks,median_weeks,max_weeks,reinjury_risk,source_note\n"
                   "hamstring,9,4,8,0.17,note\n")
    with pytest.raises(ValueError, match="line 2"):
        load_recovery_ranges_csv(bad)
    dup = tmp_path / "dup.csv"
    dup.write_text("injury_type,min_weeks,median_weeks,max_weeks,reinjury_risk,source_note\n"
                   "calf,1,2,3,0.1,a\ncalf,1,2,3,0.1,b\n")
    with pytest.raises(ValueError, match="duplicate"):
        load_recovery_ranges_csv(dup)
