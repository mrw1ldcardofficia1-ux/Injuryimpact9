from datetime import datetime, timezone

import pytest

from injuryimpact.report import build_report, load_clubs
from injuryimpact.site import render

NOW = datetime(2026, 10, 22, 12, tzinfo=timezone.utc)


def write(d, name, text):
    (d / name).write_text(text, encoding="utf-8")


def test_twenty_real_clubs_unique_and_complete():
    clubs = load_clubs()
    assert len(clubs) == 20
    names = {c["name"] for c in clubs}
    for must in ["Arsenal", "Coventry City", "Hull City", "Ipswich Town", "Sunderland", "Leeds United"]:
        assert must in names
    for gone in ["West Ham United", "Burnley", "Wolverhampton Wanderers"]:
        assert gone not in names
    assert all(c["crest"] and c["colour"].startswith("#") and c["short"] for c in clubs)


def test_one_to_watch_is_highest_impact_per_club(tmp_path):
    write(tmp_path, "injuries.csv",
          "club,player,position,injury_type,status,start_date,date_of_birth,minutes,goals,assists,rating\n"
          "arsenal,Star Man,FWD,hamstring strain,out,2026-10-15,1995-01-01,800,8,4,0.9\n"
          "arsenal,Bench Man,MID,calf strain,doubtful,2026-10-15,1995-01-01,90,0,0,0.1\n"
          "chelsea,Only One,DEF,ankle sprain,out,2026-10-15,2000-01-01,700,1,1,0.5\n"
          "nowhere,Ghost,DEF,calf,out,2026-10-15,2000-01-01,700,1,1,0.5\n")
    write(tmp_path, "team_stats.csv", "club,matches_played,total_goals\narsenal,10,20\nchelsea,10,15\n")
    by = {c.id: c for c in build_report(tmp_path, as_of=NOW)}
    assert [p.name for p in by["arsenal"].players] == ["Star Man", "Bench Man"]
    assert by["arsenal"].players[0].watch and not by["arsenal"].players[1].watch
    assert by["chelsea"].players[0].watch
    assert by["everton"].players == []                    # clubs with no injuries still listed
    assert sum(len(c.players) for c in by.values()) == 3  # unknown club skipped


def test_unknown_injury_flagged_not_guessed(tmp_path):
    write(tmp_path, "injuries.csv",
          "club,player,position,injury_type,status,start_date,date_of_birth,minutes,goals,assists,rating\n"
          "arsenal,Mystery,MID,knock,out,2026-10-15,,100,0,0,\n")
    p = {c.id: c for c in build_report(tmp_path, as_of=NOW)}["arsenal"].players[0]
    assert p.needs_review and p.injury_type is None and p.return_weeks_min is None


def test_example_row_and_empty_data_ignored(tmp_path):
    write(tmp_path, "injuries.csv",
          "club,player,position,injury_type,status,start_date,date_of_birth,minutes,goals,assists,rating\n"
          "EXAMPLE_ROW_DELETE_ME,Example Player,MID,hamstring,out,2026-10-10,,1,0,0,\n")
    assert all(not c.players for c in build_report(tmp_path, as_of=NOW))


def test_html_has_names_crest_watch_and_escapes(tmp_path):
    write(tmp_path, "injuries.csv",
          "club,player,position,injury_type,status,start_date,date_of_birth,minutes,goals,assists,rating\n"
          'liverpool,"<b>X</b> Player",FWD,hamstring,out,2026-10-15,,800,5,5,0.8\n')
    write(tmp_path, "team_stats.csv", "club,matches_played,total_goals\nliverpool,10,20\n")
    html = render(build_report(tmp_path, as_of=NOW), NOW, "2026-27")
    assert "Liverpool" in html and "Tottenham Hotspur" in html and "crests/liverpool.svg" in html
    assert "ONE TO WATCH" in html and "&lt;b&gt;X&lt;/b&gt; Player" in html and "<b>X</b>" not in html
    assert "not medical advice" in html.lower()
