import shutil
from pathlib import Path

import pytest
import yaml

from injuryimpact.config import (DEFAULT_CONFIG_DIR, ConfigError, MissingSecretError,
                                 get_secret, load_aliases, load_settings)


def _copy_config(tmp_path: Path) -> Path:
    dest = tmp_path / "config"
    shutil.copytree(DEFAULT_CONFIG_DIR, dest)
    return dest


def test_default_config_loads():
    s = load_settings()
    assert s.impact.weights == {"minutes_share": 0.4, "goal_contribution_share": 0.3,
                                "replacement_gap": 0.2, "fixture_difficulty": 0.1}
    assert s.providers["api_football"].daily_limit == 100
    assert s.weights_version.startswith("v1.0+")


def test_risky_providers_disabled_by_default():
    s = load_settings()
    assert not s.providers["fpl"].enabled
    assert not s.providers["sportmonks"].enabled
    assert not s.providers["licensed_feed"].enabled


def test_weights_must_sum_to_one(tmp_path):
    cfg = _copy_config(tmp_path)
    data = yaml.safe_load((cfg / "weights.yaml").read_text())
    data["impact"]["weights"]["minutes_share"] = 0.5
    (cfg / "weights.yaml").write_text(yaml.safe_dump(data))
    with pytest.raises(ConfigError, match="sum to 1.0"):
        load_settings(cfg)


def test_unknown_weight_key_rejected(tmp_path):
    cfg = _copy_config(tmp_path)
    data = yaml.safe_load((cfg / "weights.yaml").read_text())
    data["impact"]["weights"]["vibes"] = 0.0
    (cfg / "weights.yaml").write_text(yaml.safe_dump(data))
    with pytest.raises(ConfigError):
        load_settings(cfg)


def test_fingerprint_changes_when_weights_change(tmp_path):
    cfg = _copy_config(tmp_path)
    before = load_settings(cfg).impact.fingerprint
    data = yaml.safe_load((cfg / "weights.yaml").read_text())
    data["impact"]["weights"].update(minutes_share=0.5, goal_contribution_share=0.2)
    (cfg / "weights.yaml").write_text(yaml.safe_dump(data))
    assert load_settings(cfg).impact.fingerprint != before


def test_missing_secret_raises(monkeypatch):
    monkeypatch.delenv("API_FOOTBALL_KEY", raising=False)
    with pytest.raises(MissingSecretError):
        get_secret("API_FOOTBALL_KEY")


def test_secret_read_from_env(monkeypatch):
    monkeypatch.setenv("API_FOOTBALL_KEY", "abc123")
    assert get_secret("API_FOOTBALL_KEY") == "abc123"


def test_aliases_cover_the_ten_injury_types():
    assert set(load_aliases()) == {"hamstring", "ankle sprain", "acl", "calf", "groin",
                                   "knee ligament", "concussion", "muscle strain", "fracture", "illness"}
