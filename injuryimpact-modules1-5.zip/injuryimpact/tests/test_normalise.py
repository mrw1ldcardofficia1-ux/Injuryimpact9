from datetime import date, datetime, timezone

import pytest

from injuryimpact.config import ConfigError
from injuryimpact.normalise import (InjuryTypeNormalizer, normalise_position, normalise_status,
                                    parse_date, parse_datetime, status_from_chance_of_playing)
from injuryimpact.types import InjuryStatus, Position

N = InjuryTypeNormalizer.from_config()


@pytest.mark.parametrize("raw,expected", [
    ("hamstring strain", "hamstring"),
    ("Hamstring tightness", "hamstring"),
    ("  HAMSTRING   injury ", "hamstring"),
    ("Sprained Ankle", "ankle sprain"),
    ("ACL", "acl"),
    ("Anterior Cruciate Ligament", "acl"),
    ("head injury", "concussion"),
    ("stomach bug", "illness"),
    ("ill", "illness"),
    ("Broken foot", "fracture"),
    ("hamstring-strain", "hamstring"),
])
def test_exact_aliases(raw, expected):
    m = N.normalise(raw)
    assert m.canonical == expected and not m.needs_review


def test_partial_match_inside_longer_text():
    m = N.normalise("Returning from a grade 2 hamstring tear")
    assert m.canonical == "hamstring" and m.match_kind == "partial" and not m.needs_review


@pytest.mark.parametrize("raw", ["knock", "undisclosed", "fitness", "knee injury", "something odd", "foot injury"])
def test_unknown_types_are_flagged_not_guessed(raw):
    m = N.normalise(raw)
    assert m.canonical is None and m.needs_review and m.match_kind == "unknown"
    assert raw in m.reason


@pytest.mark.parametrize("raw", [None, "", "   ", "---"])
def test_missing_type_flagged(raw):
    m = N.normalise(raw)
    assert m.canonical is None and m.needs_review and "missing" in m.reason


def test_ambiguous_type_flagged():
    m = N.normalise("hamstring and calf problems")
    assert m.canonical is None and m.needs_review and m.match_kind == "ambiguous"
    assert "calf" in m.reason and "hamstring" in m.reason


def test_ill_is_not_matched_inside_other_words():
    assert N.normalise("still unsure about the pitch").needs_review


def test_conflicting_alias_config_rejected():
    with pytest.raises(ConfigError):
        InjuryTypeNormalizer({"calf": ["strain"], "groin": ["strain"]})


def test_all_ten_canonical_types_present():
    assert len(N.canonical_types) == 10


# --- status -----------------------------------------------------------------
@pytest.mark.parametrize("raw,expected", [
    ("Out", InjuryStatus.OUT), ("Missing Fixture", InjuryStatus.OUT), ("ruled out for 6 weeks", InjuryStatus.OUT),
    ("Questionable", InjuryStatus.DOUBTFUL), ("50-50", InjuryStatus.DOUBTFUL), ("Doubtful for Saturday", InjuryStatus.DOUBTFUL),
    ("Back in training", InjuryStatus.RETURNING), ("nearing return", InjuryStatus.RETURNING),
    (InjuryStatus.OUT, InjuryStatus.OUT),
])
def test_status_mapping(raw, expected):
    r = normalise_status(raw)
    assert r.status == expected and not r.needs_review


@pytest.mark.parametrize("raw", [None, "", "suspended", "banana"])
def test_unknown_status_flagged(raw):
    r = normalise_status(raw)
    assert r.status is None and r.needs_review


def test_ambiguous_status_flagged():
    assert normalise_status("doubtful but back in training").needs_review


@pytest.mark.parametrize("pct,expected", [
    (None, None), (100, None), (75, InjuryStatus.DOUBTFUL), (25, InjuryStatus.DOUBTFUL), (0, InjuryStatus.OUT)])
def test_chance_of_playing(pct, expected):
    assert status_from_chance_of_playing(pct) == expected


def test_chance_of_playing_out_of_range():
    with pytest.raises(ValueError):
        status_from_chance_of_playing(120)


# --- position ---------------------------------------------------------------
def test_positions():
    assert normalise_position("Goalkeeper") == Position.GK
    assert normalise_position("Attacker") == Position.FWD
    assert normalise_position("Centre-Back") == Position.DEF
    assert normalise_position("Midfielder") == Position.MID
    assert normalise_position("coach") is None


# --- dates ------------------------------------------------------------------
@pytest.mark.parametrize("raw,expected", [
    ("2026-10-22", date(2026, 10, 22)),
    ("2026-10-22T14:30:00+00:00", date(2026, 10, 22)),
    ("2026-10-22T14:30:00Z", date(2026, 10, 22)),
    ("22/10/2026", date(2026, 10, 22)),
    ("03/04/2026", date(2026, 4, 3)),            # day-first (UK)
    ("22 Oct 2026", date(2026, 10, 22)),
    ("22 October 2026", date(2026, 10, 22)),
    ("Oct 22, 2026", date(2026, 10, 22)),
    (date(2026, 10, 22), date(2026, 10, 22)),
])
def test_parse_date(raw, expected):
    assert parse_date(raw) == expected


@pytest.mark.parametrize("raw", [None, "", "soon", "31/02/2026", "1970-01-01", True, "2026-13-40"])
def test_parse_date_rejects_garbage_and_implausible(raw):
    assert parse_date(raw) is None


def test_datetime_is_utc_aware():
    dt = parse_datetime("2026-10-22T15:00:00+01:00")
    assert dt == datetime(2026, 10, 22, 14, 0, tzinfo=timezone.utc)
    assert parse_datetime("2026-10-22T15:00:00").tzinfo is not None


def test_epoch_seconds_and_millis():
    assert parse_datetime(1792677600) == parse_datetime(1792677600000)
