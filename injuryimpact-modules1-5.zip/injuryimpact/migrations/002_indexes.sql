-- InjuryImpact indexes (PostgreSQL / Supabase).
BEGIN;

CREATE INDEX ix_players_club_id ON players (club_id);
CREATE INDEX ix_external_ids_entity_internal ON external_ids (entity, internal_id);
CREATE INDEX ix_raw_payloads_lookup ON raw_source_payloads (source_name, endpoint, params_hash, fetched_at DESC);

CREATE INDEX ix_injuries_player_id ON injuries (player_id);
CREATE INDEX ix_injuries_status ON injuries (status);
-- One active injury per player: also catches duplicate-player records.
CREATE UNIQUE INDEX uq_injuries_one_active_per_player ON injuries (player_id) WHERE is_active;
CREATE INDEX ix_injuries_needs_review ON injuries (id) WHERE needs_review;

CREATE INDEX ix_injury_obs_player_reported ON injury_observations (player_id, reported_at DESC);

CREATE INDEX ix_fixtures_season_kickoff ON fixtures (season, kickoff);
CREATE INDEX ix_fixtures_home_club ON fixtures (home_club_id);
CREATE INDEX ix_fixtures_away_club ON fixtures (away_club_id);

CREATE INDEX ix_impact_scores_injury ON impact_scores (injury_id, calculated_at DESC);
CREATE INDEX ix_club_impact_scores_club ON club_impact_scores (club_id, calculated_at DESC);

CREATE INDEX ix_change_log_entity ON change_log (entity, entity_id, changed_at DESC);
CREATE INDEX ix_change_log_changed_at ON change_log (changed_at);

COMMIT;
