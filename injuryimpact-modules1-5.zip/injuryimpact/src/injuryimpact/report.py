"""Build the per-club injury report (injured players, impact scores, one to watch).

Inputs are plain CSV files so real data can be pasted in by hand or written by an adapter:
  data/injuries.csv    club, player, position, injury_type, status, start_date, date_of_birth,
                       minutes, goals, assists, rating            (club = id from clubs.yaml)
  data/team_stats.csv  club, matches_played, total_goals
  data/fixtures.csv    kickoff (ISO, UTC), home, away, difficulty_home, difficulty_away

"One to watch" = the injured player on that club with the highest Impact Score, because
that absence is the one most likely to change results. Nothing here is medical advice;
recovery times are estimates.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import yaml

from .config import DEFAULT_CONFIG_DIR, Settings, load_settings
from .impact import FixtureView, compute_impact
from .normalise import InjuryTypeNormalizer, normalise_position, normalise_status, parse_date, parse_datetime
from .recovery import RecoveryRangeData, estimate_recovery, load_recovery_ranges_csv, remaining_range
from .types import MEDICAL_DISCLAIMER

STATUS_ORDER = {"out": 0, "doubtful": 1, "returning": 2}


@dataclass
class Stats:
    minutes: int = 0
    goals: int = 0
    assists: int = 0


@dataclass
class TeamStats:
    total_minutes_available: int = 0
    total_goals: int = 0


@dataclass
class PlayerRow:
    name: str
    position: Optional[str]
    injury_type: Optional[str]
    injury_raw: str
    status: str
    score: float
    return_weeks_min: Optional[float]
    return_weeks_max: Optional[float]
    overdue: bool
    limited_data: bool
    needs_review: bool
    review_reason: Optional[str]
    watch: bool = False


@dataclass
class ClubReport:
    id: str
    name: str
    short: str
    colour: str
    crest: str
    players: list[PlayerRow] = field(default_factory=list)

    @property
    def top_score(self) -> float:
        return max((p.score for p in self.players), default=0.0)


def load_clubs(config_dir: Path | str | None = None) -> list[dict[str, Any]]:
    base = Path(config_dir or DEFAULT_CONFIG_DIR)
    data = yaml.safe_load((base / "clubs.yaml").read_text(encoding="utf-8"))
    clubs = data["clubs"]
    ids = [c["id"] for c in clubs]
    if len(set(ids)) != len(ids):
        raise ValueError("clubs.yaml has duplicate club ids")
    return clubs


def _rows(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        return []
    with open(path, newline="", encoding="utf-8") as fh:
        return [{k.strip(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(fh)]


def _num(value: str, default: float = 0) -> float:
    try:
        return float(value) if value != "" else default
    except ValueError:
        return default


def build_report(
    data_dir: Path | str,
    *,
    as_of: datetime,
    settings: Optional[Settings] = None,
    config_dir: Path | str | None = None,
    ranges: Optional[dict[str, RecoveryRangeData]] = None,
) -> list[ClubReport]:
    data = Path(data_dir)
    s = settings or load_settings(config_dir)
    clubs = load_clubs(config_dir)
    by_id = {c["id"]: ClubReport(c["id"], c["name"], c["short"], c["colour"], c["crest"]) for c in clubs}
    normaliser = InjuryTypeNormalizer.from_config(config_dir)
    if ranges is None:
        rpath = Path(config_dir or DEFAULT_CONFIG_DIR) / "recovery_ranges.csv"
        ranges = load_recovery_ranges_csv(rpath) if rpath.is_file() else {}

    team: dict[str, TeamStats] = {}
    for r in _rows(data / "team_stats.csv"):
        mp = int(_num(r.get("matches_played", "0")))
        team[r["club"]] = TeamStats(mp * 90, int(_num(r.get("total_goals", "0"))))

    fixtures: list[FixtureView] = []
    for r in _rows(data / "fixtures.csv"):
        ko = parse_datetime(r.get("kickoff"))
        if ko is None:
            continue
        dh, da = r.get("difficulty_home", ""), r.get("difficulty_away", "")
        fixtures.append(FixtureView(ko, r["home"], r["away"],
                                    _num(dh) if dh != "" else None, _num(da) if da != "" else None))

    for i, r in enumerate(_rows(data / "injuries.csv"), start=1):
        club = r.get("club", "")
        if club.startswith("EXAMPLE") or club not in by_id:
            continue                                  # unknown clubs are skipped, never guessed
        status = normalise_status(r.get("status"))
        match = normaliser.normalise(r.get("injury_type"))
        pos = normalise_position(r.get("position"))
        start = parse_date(r.get("start_date"))
        dob = parse_date(r.get("date_of_birth"))
        stats = Stats(int(_num(r.get("minutes", "0"))), int(_num(r.get("goals", "0"))),
                      int(_num(r.get("assists", "0"))))
        rating = _num(r["rating"]) if r.get("rating", "") != "" else None

        est = estimate_recovery(match.canonical, ranges, s.recovery, as_of=as_of.date(), date_of_birth=dob) \
            if match.canonical else None
        result = compute_impact(
            injury_id=i, club=club, player_stats=stats, team_stats=team.get(club), rating=rating,
            estimate=est, start_date=start, fixtures=fixtures, cfg=s.impact,
            weights_version=s.weights_version, as_of=as_of)
        rem = remaining_range(est, start, as_of.date()) if est else None
        by_id[club].players.append(PlayerRow(
            name=r.get("player", "?"), position=pos.value if pos else None,
            injury_type=match.canonical, injury_raw=r.get("injury_type", ""),
            status=status.status.value if status.status else "unknown",
            score=result.score,
            return_weeks_min=rem.min_weeks if rem else None, return_weeks_max=rem.max_weeks if rem else None,
            overdue=result.components.overdue, limited_data=result.components.limited_data,
            needs_review=match.needs_review or status.needs_review,
            review_reason=match.reason or status.reason))

    out = list(by_id.values())
    for c in out:
        c.players.sort(key=lambda p: (-p.score, STATUS_ORDER.get(p.status, 9), p.name))
        if c.players and c.players[0].score > 0:
            c.players[0].watch = True
    return out


def default_as_of() -> datetime:
    return datetime.now(timezone.utc)


__all__ = ["build_report", "ClubReport", "PlayerRow", "load_clubs", "default_as_of", "MEDICAL_DISCLAIMER"]
