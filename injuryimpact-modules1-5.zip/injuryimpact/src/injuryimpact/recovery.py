"""Recovery estimation.

APIs do not reliably provide return dates, so every range comes from the
``recovery_ranges`` table, adjusted by modifiers, and is ALWAYS an estimate.
The ranges are total expected absence measured from the injury start date.
Nothing here is medical advice.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Iterable, Mapping, Optional

from .config import RecoveryConfig
from .types import RecoveryEstimate

if TYPE_CHECKING:  # avoid a hard SQLAlchemy dependency for pure-logic use and tests
    from sqlalchemy.orm import Session


@dataclass(frozen=True)
class RecoveryRangeData:
    injury_type: str
    min_weeks: float
    median_weeks: float
    max_weeks: float
    reinjury_risk: float
    source_note: str

    def __post_init__(self) -> None:
        if not (0 <= self.min_weeks <= self.median_weeks <= self.max_weeks):
            raise ValueError(f"{self.injury_type}: need 0 <= min <= median <= max weeks")
        if not 0 <= self.reinjury_risk <= 1:
            raise ValueError(f"{self.injury_type}: reinjury_risk must be between 0 and 1")


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------
def load_recovery_ranges_csv(path: Path | str) -> dict[str, RecoveryRangeData]:
    required = {"injury_type", "min_weeks", "median_weeks", "max_weeks", "reinjury_risk", "source_note"}
    out: dict[str, RecoveryRangeData] = {}
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"{path}: missing columns {sorted(missing)}")
        for i, row in enumerate(reader, start=2):
            try:
                item = RecoveryRangeData(
                    injury_type=row["injury_type"].strip().lower(),
                    min_weeks=float(row["min_weeks"]), median_weeks=float(row["median_weeks"]),
                    max_weeks=float(row["max_weeks"]), reinjury_risk=float(row["reinjury_risk"]),
                    source_note=row["source_note"].strip())
            except ValueError as exc:
                raise ValueError(f"{path} line {i}: {exc}") from exc
            if item.injury_type in out:
                raise ValueError(f"{path} line {i}: duplicate injury_type '{item.injury_type}'")
            out[item.injury_type] = item
    return out


def load_recovery_ranges_db(session: "Session") -> dict[str, RecoveryRangeData]:
    from sqlalchemy import select
    from .models import RecoveryRange

    return {
        r.injury_type: RecoveryRangeData(r.injury_type, r.min_weeks, r.median_weeks, r.max_weeks,
                                         r.reinjury_risk, r.source_note)
        for r in session.scalars(select(RecoveryRange))
    }


# ---------------------------------------------------------------------------
# Estimation
# ---------------------------------------------------------------------------
def full_years(born: date, as_of: date) -> int:
    return as_of.year - born.year - ((as_of.month, as_of.day) < (born.month, born.day))


def estimate_recovery(
    injury_type: Optional[str],
    ranges: Mapping[str, RecoveryRangeData],
    cfg: RecoveryConfig,
    *,
    as_of: date,
    date_of_birth: Optional[date] = None,
    previous_same_injury_dates: Iterable[date] = (),
) -> Optional[RecoveryEstimate]:
    """Return an estimated min-max absence in weeks, or None if the type is unknown.

    Modifiers (multiplicative, each applied at most once):
      * age strictly over ``cfg.age_threshold``
      * a previous injury of the SAME type that started within ``cfg.reinjury_window_days``
        before ``as_of`` (pass previous injuries only, not the current one)
    A missing date of birth simply means no age modifier is applied.
    """
    if not injury_type or injury_type not in ranges:
        return None
    base = ranges[injury_type]

    multiplier = 1.0
    applied: list[str] = []

    if date_of_birth is not None and full_years(date_of_birth, as_of) > cfg.age_threshold:
        multiplier *= cfg.age_multiplier
        applied.append(f"age>{cfg.age_threshold} x{cfg.age_multiplier}")

    if any(0 < (as_of - d).days <= cfg.reinjury_window_days for d in previous_same_injury_dates):
        multiplier *= cfg.reinjury_multiplier
        applied.append(f"same injury within {cfg.reinjury_window_days}d x{cfg.reinjury_multiplier}")

    return RecoveryEstimate(
        injury_type=injury_type,
        min_weeks=round(base.min_weeks * multiplier, 1),
        median_weeks=round(base.median_weeks * multiplier, 1),
        max_weeks=round(base.max_weeks * multiplier, 1),
        modifiers_applied=tuple(applied),
        reinjury_risk=base.reinjury_risk,
    )


@dataclass(frozen=True)
class RemainingRange:
    min_weeks: float
    max_weeks: float
    overdue: bool        # still listed as injured after the estimated maximum has passed


def remaining_range(estimate: RecoveryEstimate, start_date: Optional[date], as_of: date) -> RemainingRange:
    """Estimated weeks still to go, used by scoring to build the absence window."""
    elapsed = max(0, (as_of - start_date).days) / 7 if start_date else 0.0
    return RemainingRange(
        min_weeks=round(max(0.0, estimate.min_weeks - elapsed), 1),
        max_weeks=round(max(0.0, estimate.max_weeks - elapsed), 1),
        overdue=elapsed > estimate.max_weeks,
    )


def estimated_return_dates(start_date: date, estimate: RecoveryEstimate) -> tuple[date, date]:
    """Earliest and latest estimated return dates. Estimates only, never certainties."""
    return (start_date + timedelta(days=round(estimate.min_weeks * 7)),
            start_date + timedelta(days=round(estimate.max_weeks * 7)))
