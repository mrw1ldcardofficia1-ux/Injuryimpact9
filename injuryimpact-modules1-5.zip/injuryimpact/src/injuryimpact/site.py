"""Render the club injury report as one static, self-contained HTML page (docs/index.html).

Works with GitHub Pages: set Pages source to the /docs folder. Crests are loaded from
docs/crests/<club>.svg if you add them; otherwise a coloured monogram badge is shown.
"""
from __future__ import annotations

import argparse
from datetime import datetime
from html import escape
from pathlib import Path

from .report import ClubReport, PlayerRow, build_report, default_as_of
from .types import MEDICAL_DISCLAIMER

CSS = """
:root{--bg:#f6f7f9;--card:#fff;--text:#14171c;--muted:#5c6572;--line:#e3e6ea;--watch:#fff4d6;--watchline:#e0a800;
--out:#c0262d;--doubtful:#b86e00;--returning:#1d7a46}
@media (prefers-color-scheme:dark){:root{--bg:#0f1114;--card:#1a1d22;--text:#eceef1;--muted:#98a1ad;--line:#2c3038;
--watch:#3a3115;--watchline:#e0a800;--out:#ff6b73;--doubtful:#ffb347;--returning:#58c98a}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);
font:16px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;padding:env(safe-area-inset-top,0) 0 env(safe-area-inset-bottom,0)}
header,main,footer{max-width:760px;margin:0 auto;padding:16px}
h1{font-size:1.4rem;margin:0 0 4px}.sub{color:var(--muted);font-size:.9rem;margin:0}
.club{background:var(--card);border:1px solid var(--line);border-radius:14px;margin:14px 0;overflow:hidden}
.club-h{display:flex;align-items:center;gap:12px;padding:12px 14px;border-bottom:1px solid var(--line)}
.crest{width:44px;height:44px;flex:none;position:relative}
.crest img{width:44px;height:44px;object-fit:contain;position:relative;z-index:1}
.mono{position:absolute;inset:0;border-radius:50%;display:flex;align-items:center;justify-content:center;
color:#fff;font-weight:700;font-size:.8rem;letter-spacing:.03em}
.club-h h2{font-size:1.05rem;margin:0}.club-h .n{color:var(--muted);font-size:.85rem}
.p{padding:10px 14px;border-top:1px solid var(--line)}.p:first-of-type{border-top:0}
.p.watch{background:var(--watch);border-left:4px solid var(--watchline)}
.row{display:flex;justify-content:space-between;gap:8px;align-items:baseline}
.name{font-weight:600}.score{font-weight:700;font-variant-numeric:tabular-nums}
.meta{color:var(--muted);font-size:.85rem;margin-top:2px}
.tag{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
.out{color:var(--out)}.doubtful{color:var(--doubtful)}.returning{color:var(--returning)}
.eye{display:inline-block;background:var(--watchline);color:#201700;border-radius:6px;padding:1px 6px;
font-size:.72rem;font-weight:700;margin-right:6px}.none{padding:12px 14px;color:var(--muted);font-size:.9rem}
footer{color:var(--muted);font-size:.8rem}
"""


def _weeks(p: PlayerRow) -> str:
    if p.overdue:
        return "Past estimated return window"
    if p.return_weeks_min is None:
        return "No estimate (injury type needs review)" if p.needs_review else "No estimate"
    lo, hi = p.return_weeks_min, p.return_weeks_max
    if hi == 0:
        return "Estimated back imminently"
    return f"Est. {lo:g}\u2013{hi:g} more weeks"


def _player(p: PlayerRow) -> str:
    cls = " watch" if p.watch else ""
    eye = '<span class="eye">ONE TO WATCH</span>' if p.watch else ""
    inj = escape(p.injury_type or p.injury_raw or "unknown")
    pos = f" \u00b7 {escape(p.position)}" if p.position else ""
    flags = []
    if p.limited_data:
        flags.append("limited stats")
    if p.needs_review:
        flags.append("needs review")
    extra = f" \u00b7 {', '.join(flags)}" if flags else ""
    return (f'<div class="p{cls}"><div class="row"><span class="name">{eye}{escape(p.name)}</span>'
            f'<span class="score" title="Impact Score 0-10">{p.score:.1f}</span></div>'
            f'<div class="meta"><span class="tag {escape(p.status)}">{escape(p.status)}</span> \u00b7 {inj}{pos}'
            f' \u00b7 {escape(_weeks(p))}{extra}</div></div>')


def _club(c: ClubReport) -> str:
    n = len(c.players)
    body = "".join(_player(p) for p in c.players) or '<div class="none">No reported injuries.</div>'
    crest = (f'<div class="crest"><div class="mono" style="background:{escape(c.colour)}">{escape(c.short)}</div>'
             f'<img src="{escape(c.crest)}" alt="{escape(c.name)} crest" loading="lazy" '
             f'onerror="this.style.display=\'none\'"></div>')
    return (f'<section class="club" id="{escape(c.id)}"><div class="club-h">{crest}<div><h2>{escape(c.name)}</h2>'
            f'<div class="n">{n} injured \u00b7 top Impact {c.top_score:.1f}/10</div></div></div>{body}</section>')


def render(clubs: list[ClubReport], as_of: datetime, season: str) -> str:
    ordered = sorted(clubs, key=lambda c: (-c.top_score, c.name))
    stamp = as_of.strftime("%d %b %Y %H:%M UTC")
    return (
        '<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
        f'<title>Premier League injury impact {escape(season)}</title><style>{CSS}</style></head><body>'
        f'<header><h1>Premier League injury impact</h1><p class="sub">{escape(season)} \u00b7 updated {stamp} \u00b7 '
        'clubs ordered by their biggest absence</p></header><main>'
        + "".join(_club(c) for c in ordered) +
        f'</main><footer><p>{escape(MEDICAL_DISCLAIMER)} Impact Score (0\u201310) weighs minutes played, goal '
        'involvement, replacement gap and upcoming fixtures. Club crests belong to their owners.</p></footer>'
        '</body></html>')


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Build docs/index.html from the data CSVs")
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="docs/index.html")
    args = ap.parse_args(argv)
    from .config import load_settings

    s = load_settings()
    as_of = default_as_of()
    clubs = build_report(args.data, as_of=as_of, settings=s)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(render(clubs, as_of, s.season), encoding="utf-8")
    print(f"wrote {out} ({sum(len(c.players) for c in clubs)} injured players, {len(clubs)} clubs)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
