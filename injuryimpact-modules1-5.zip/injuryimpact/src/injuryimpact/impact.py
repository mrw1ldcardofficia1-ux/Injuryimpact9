"""Impact Score for a single injury.

score = scale_max * sum(weight_i * component_i), every component on a 0-1 scale:

* minutes_share           player minutes / (matches_played * 90)
* goal_contribution_share (goals + assists) / team goals, capped at 1
* replacement_gap         manual 0-1 rating; the configured default is used when unrated
* fixture_difficulty      mean difficulty of the club's fixtures inside the remaining
                          absence window; neutral when the window has no usable fixtures

Missing data is never guessed. Zero minutes or missing team stats give shares of 0 and
set ``limited_data`` so the UI can show lower confidence. A player still listed after the
estimated maximum (overdue), or an injury with no estimate, has an empty window and
neutral fixture difficulty. The score is an estimate, not medical advice.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Any, Iterable, Optional, Protocol

from .config import ImpactConfig
from .recovery import remaining_range
from .types import ImpactComponents, ImpactResult, RecoveryEstimate


class PlayerStatsLike(Protocol):
    minutes: int
    goals: int
    assists: int


class TeamStatsLike(Protocol):
    total_minutes_available: int
    total_goals: int


@dataclass(frozen=True)
class FixtureView:
    """Minimal fixture shape for scoring (works with DB rows or adapter output)."""

    kickoff: datetime
    home_club: Any
    away_club: Any
    difficulty_home: Optional[float] = None
    difficulty_away: Optional[float] = None
    status: str = "scheduled"


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def _check_aware(dt: datetime, name: str) -> None:
    if dt.tzinfo is None:
        raise ValueError(f"{name} must be timezone-aware (UTC)")


# ---------------------------------------------------------------------------
# Components
# ---------------------------------------------------------------------------
def minutes_share(player: Optional[PlayerStatsLike], team: Optional[TeamStatsLike]) -> tuple[float, bool]:
    """Return (share 0-1, limited_data)."""
    if player is None or team is None:
        return 0.0, True
    if player.minutes < 0:
        raise ValueError("player minutes cannot be negative")
    if team.total_minutes_available <= 0 or player.minutes == 0:
        return 0.0, True
    return _clamp01(player.minutes / team.total_minutes_available), False


def goal_contribution_share(player: Optional[PlayerStatsLike], team: Optional[TeamStatsLike]) -> float:
    """(goals + assists) / team goals. Zero goals is a real 0; no team goals yet is also 0."""
    if player is None or team is None:
        return 0.0
    if player.goals < 0 or player.assists < 0:
        raise ValueError("goals and assists cannot be negative")
    if team.total_goals <= 0:
        return 0.0
    return _clamp01((player.goals + player.assists) / team.total_goals)


def replacement_gap(rating: Optional[float], default: float) -> tuple[float, bool]:
    """Return (value, defaulted). A rating outside 0-1 is an error, not silently clamped."""
    if rating is None:
        return default, True
    if not 0.0 <= rating <= 1.0:
        raise ValueError(f"replacement_gap must be between 0 and 1, got {rating}")
    return float(rating), False


def fixture_difficulty(
    club: Any,
    fixtures: Iterable[FixtureView],
    *,
    as_of: datetime,
    window_weeks: Optional[float],
    neutral: float,
) -> tuple[float, int]:
    """Mean difficulty for ``club`` over fixtures kicking off in (as_of, as_of + window_weeks].

    Returns (difficulty, fixtures_used). With no window or no usable fixtures the neutral
    value is returned with fixtures_used == 0. Fixtures that are not scheduled, do not
    involve the club, or have no difficulty value are ignored.
    """
    _check_aware(as_of, "as_of")
    if window_weeks is None or window_weeks <= 0:
        return neutral, 0
    end = as_of + timedelta(days=window_weeks * 7)
    values: list[float] = []
    for f in fixtures:
        _check_aware(f.kickoff, "fixture kickoff")
        if f.status != "scheduled" or not (as_of < f.kickoff <= end):
            continue
        if f.home_club == club:
            d = f.difficulty_home
        elif f.away_club == club:
            d = f.difficulty_away
        else:
            continue
        if d is not None:
            values.append(_clamp01(d))
    if not values:
        return neutral, 0
    return sum(values) / len(values), len(values)


# ---------------------------------------------------------------------------
# Score
# ---------------------------------------------------------------------------
def compute_impact(
    *,
    injury_id: int,
    club: Any,
    player_stats: Optional[PlayerStatsLike],
    team_stats: Optional[TeamStatsLike],
    rating: Optional[float],
    estimate: Optional[RecoveryEstimate],
    start_date: Optional[date],
    fixtures: Iterable[FixtureView],
    cfg: ImpactConfig,
    weights_version: str,
    as_of: datetime,
) -> ImpactResult:
    _check_aware(as_of, "as_of")

    m_share, limited = minutes_share(player_stats, team_stats)
    g_share = goal_contribution_share(player_stats, team_stats)
    gap, gap_defaulted = replacement_gap(rating, cfg.default_replacement_gap)

    window_weeks: Optional[float] = None
    overdue = False
    if estimate is not None:
        rem = remaining_range(estimate, start_date, as_of.date())
        overdue = rem.overdue
        window_weeks = None if overdue else rem.max_weeks
    difficulty, used = fixture_difficulty(
        club, fixtures, as_of=as_of, window_weeks=window_weeks, neutral=cfg.neutral_fixture_difficulty)

    parts = {
        "minutes_share": m_share,
        "goal_contribution_share": g_share,
        "replacement_gap": gap,
        "fixture_difficulty": difficulty,
    }
    raw = _clamp01(sum(cfg.weights[k] * v for k, v in parts.items()))

    components = ImpactComponents(
        **parts,
        weights=dict(cfg.weights),
        raw_score=raw,
        scale_max=cfg.scale_max,
        replacement_gap_defaulted=gap_defaulted,
        fixture_window_empty=used == 0,
        fixtures_in_window=used,
        overdue=overdue,
        limited_data=limited,
    )
    return ImpactResult(
        injury_id=injury_id,
        score=round(raw * cfg.scale_max, 2),
        components=components,
        weights_version=weights_version,
    )
