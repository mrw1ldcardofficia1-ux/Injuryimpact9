"""Normalisation of injury types, statuses, positions and dates.

Rules
-----
* Never guess. Anything that does not map cleanly is returned with
  ``needs_review=True`` and a reason, and the pipeline flags the record.
* Pure functions / small classes with no database access.
* Naive datetimes are assumed to be UTC. Day-first (UK) order is assumed for
  ambiguous numeric dates such as 03/04/2026.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Optional

from .config import ConfigError, load_aliases
from .types import InjuryStatus, Position

# Too generic to match inside a longer phrase; exact match only.
EXACT_ONLY_TYPE_ALIASES = frozenset({"ill"})
EXACT_ONLY_STATUS_ALIASES = frozenset({"out", "injured", "injury", "missing", "return", "recovering"})


def clean_text(value: Any) -> str:
    """Lower-case, strip accents and punctuation, collapse whitespace."""
    if value is None:
        return ""
    text = unicodedata.normalize("NFKD", str(value)).encode("ascii", "ignore").decode("ascii")
    text = text.lower().replace("'", "")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return text.strip()


def _contains_phrase(haystack: str, phrase: str) -> bool:
    return re.search(rf"(?<![a-z0-9]){re.escape(phrase)}(?![a-z0-9])", haystack) is not None


# ---------------------------------------------------------------------------
# Injury types
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class TypeMatch:
    raw: str
    canonical: Optional[str]
    match_kind: str                  # exact | partial | ambiguous | unknown
    needs_review: bool
    reason: Optional[str] = None


class InjuryTypeNormalizer:
    """Maps free-text injury descriptions to canonical types using config/injury_aliases.yaml."""

    def __init__(self, aliases: dict[str, list[str]]):
        self._alias_to_type: dict[str, str] = {}
        for canonical, names in aliases.items():
            for name in [canonical, *names]:
                key = clean_text(name)
                if not key:
                    continue
                existing = self._alias_to_type.get(key)
                if existing is not None and existing != canonical:
                    raise ConfigError(f"Alias '{key}' maps to both '{existing}' and '{canonical}'.")
                self._alias_to_type[key] = canonical
        # Longest first so "hamstring strain" is tried before "hamstring".
        self._partial_aliases = sorted(
            (a for a in self._alias_to_type if a not in EXACT_ONLY_TYPE_ALIASES), key=len, reverse=True)

    @classmethod
    def from_config(cls, config_dir: Optional[Path | str] = None) -> "InjuryTypeNormalizer":
        return cls(load_aliases(config_dir))

    @property
    def canonical_types(self) -> set[str]:
        return set(self._alias_to_type.values())

    def normalise(self, raw: Any) -> TypeMatch:
        raw_s = "" if raw is None else str(raw)
        cleaned = clean_text(raw_s)
        if not cleaned:
            return TypeMatch(raw_s, None, "unknown", True, "missing injury type")

        if cleaned in self._alias_to_type:
            return TypeMatch(raw_s, self._alias_to_type[cleaned], "exact", False)

        found = {self._alias_to_type[a] for a in self._partial_aliases if _contains_phrase(cleaned, a)}
        if len(found) == 1:
            return TypeMatch(raw_s, next(iter(found)), "partial", False)
        if len(found) > 1:
            return TypeMatch(raw_s, None, "ambiguous", True,
                             f"ambiguous injury type, matches: {', '.join(sorted(found))}")
        return TypeMatch(raw_s, None, "unknown", True, f"unknown injury type: '{raw_s.strip()}'")


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------
_STATUS_ALIASES: dict[InjuryStatus, tuple[str, ...]] = {
    InjuryStatus.OUT: (
        "out", "injured", "injury", "missing", "missing fixture", "ruled out", "sidelined",
        "unavailable", "long term", "long term injury", "season ending", "out for season"),
    InjuryStatus.DOUBTFUL: (
        "doubtful", "doubt", "a doubt", "major doubt", "minor doubt", "questionable",
        "fitness test", "late fitness test", "game time decision", "touch and go", "50 50", "knock"),
    InjuryStatus.RETURNING: (
        "returning", "return", "back in training", "returned to training", "back in team training",
        "nearing return", "close to return", "back soon", "available soon", "recovering"),
}
_STATUS_LOOKUP = {clean_text(a): st for st, names in _STATUS_ALIASES.items() for a in names}
_STATUS_PARTIAL = sorted((a for a in _STATUS_LOOKUP if a not in EXACT_ONLY_STATUS_ALIASES), key=len, reverse=True)


@dataclass(frozen=True)
class StatusMatch:
    raw: str
    status: Optional[InjuryStatus]
    needs_review: bool
    reason: Optional[str] = None


def normalise_status(raw: Any) -> StatusMatch:
    if isinstance(raw, InjuryStatus):
        return StatusMatch(raw.value, raw, False)
    raw_s = "" if raw is None else str(raw)
    cleaned = clean_text(raw_s)
    if not cleaned:
        return StatusMatch(raw_s, None, True, "missing status")
    if cleaned in _STATUS_LOOKUP:
        return StatusMatch(raw_s, _STATUS_LOOKUP[cleaned], False)
    found = {_STATUS_LOOKUP[a] for a in _STATUS_PARTIAL if _contains_phrase(cleaned, a)}
    if len(found) == 1:
        return StatusMatch(raw_s, next(iter(found)), False)
    if len(found) > 1:
        return StatusMatch(raw_s, None, True,
                           f"ambiguous status, matches: {', '.join(sorted(s.value for s in found))}")
    return StatusMatch(raw_s, None, True, f"unknown status: '{raw_s.strip()}'")


def status_from_chance_of_playing(pct: Optional[float]) -> Optional[InjuryStatus]:
    """FPL-style chance_of_playing_next_round: 0 -> out, 1-99 -> doubtful, 100/None -> no signal."""
    if pct is None:
        return None
    if not 0 <= pct <= 100:
        raise ValueError(f"chance_of_playing must be 0-100, got {pct}")
    if pct == 0:
        return InjuryStatus.OUT
    if pct < 100:
        return InjuryStatus.DOUBTFUL
    return None


# ---------------------------------------------------------------------------
# Position
# ---------------------------------------------------------------------------
_POSITION_ALIASES = {
    Position.GK: ("goalkeeper", "gk", "keeper", "goalie"),
    Position.DEF: ("defender", "def", "defence", "centre back", "center back", "cb", "full back",
                   "fullback", "lb", "rb", "left back", "right back", "wing back"),
    Position.MID: ("midfielder", "mid", "midfield", "cm", "dm", "am", "cdm", "cam"),
    Position.FWD: ("attacker", "forward", "fwd", "striker", "st", "winger", "lw", "rw", "centre forward"),
}
_POSITION_LOOKUP = {clean_text(a): p for p, names in _POSITION_ALIASES.items() for a in names}


def normalise_position(raw: Any) -> Optional[Position]:
    if isinstance(raw, Position):
        return raw
    return _POSITION_LOOKUP.get(clean_text(raw))


# ---------------------------------------------------------------------------
# Dates
# ---------------------------------------------------------------------------
_DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d %b %Y", "%d %B %Y", "%b %d, %Y", "%B %d, %Y")
_MIN_YEAR, _MAX_YEAR = 2000, 2100


def _plausible(dt: datetime) -> Optional[datetime]:
    return dt if _MIN_YEAR <= dt.year <= _MAX_YEAR else None


def parse_datetime(value: Any) -> Optional[datetime]:
    """Return a timezone-aware UTC datetime, or None if the value cannot be parsed."""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, datetime):
        dt = value if value.tzinfo else value.replace(tzinfo=timezone.utc)
        return _plausible(dt.astimezone(timezone.utc))
    if isinstance(value, date):
        return _plausible(datetime(value.year, value.month, value.day, tzinfo=timezone.utc))
    if isinstance(value, (int, float)):
        seconds = value / 1000 if value > 1e11 else value      # tolerate epoch milliseconds
        try:
            return _plausible(datetime.fromtimestamp(seconds, tz=timezone.utc))
        except (OverflowError, OSError, ValueError):
            return None
    text = str(value).strip()
    if not text:
        return None
    try:
        dt = datetime.fromisoformat(text)
        dt = dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        return _plausible(dt.astimezone(timezone.utc))
    except ValueError:
        pass
    for fmt in _DATE_FORMATS:
        try:
            return _plausible(datetime.strptime(text, fmt).replace(tzinfo=timezone.utc))
        except ValueError:
            continue
    return None


def parse_date(value: Any) -> Optional[date]:
    """Return a calendar date (UTC), or None if the value cannot be parsed."""
    if isinstance(value, datetime):
        dt = parse_datetime(value)
        return dt.date() if dt else None
    if isinstance(value, date):
        return value if _MIN_YEAR <= value.year <= _MAX_YEAR else None
    dt = parse_datetime(value)
    return dt.date() if dt else None
