"""API-Football (api-sports.io) adapter: injuries, team stats and player stats -> CSV files.

Calls used per run (free tier = 100/day, normal runs stop at 90%):
  1  /injuries            2  /teams (id -> club mapping)
  with --with-stats: up to 20 x /teams/statistics, plus 1 x /players per injured player.

The API reports injuries PER FIXTURE ("this player may miss match X"), so a current injury is
a player listed for a recent or upcoming fixture. The start date is approximated as the first
fixture of the latest unbroken run of the same reason. It is an estimate, not a medical record.
Nothing here is medical advice. The API key comes from the API_FOOTBALL_KEY environment variable.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

from ..config import get_secret, load_dotenv_if_available, load_settings
from ..normalise import clean_text, normalise_position, normalise_status, parse_datetime
from ..report import load_clubs
from ..types import NormInjury

PROVIDER = "api_football"
SOURCE_NAME = "API-Football"
INJURY_COLUMNS = ["club", "player", "position", "injury_type", "status", "start_date", "date_of_birth",
                  "minutes", "goals", "assists", "rating"]


class ApiFootballError(RuntimeError):
    pass


class BudgetExceeded(ApiFootballError):
    pass


# ---------------------------------------------------------------------------
# Daily call budget (persisted so repeated runs share the same daily limit)
# ---------------------------------------------------------------------------
class BudgetTracker:
    def __init__(self, path: Path | str, daily_limit: int, stop_fraction: float = 0.9):
        self.path, self.daily_limit, self.stop_fraction = Path(path), daily_limit, stop_fraction

    def _load(self, today: date) -> int:
        try:
            d = json.loads(self.path.read_text(encoding="utf-8"))
            return int(d["calls"]) if d.get("date") == today.isoformat() else 0
        except (OSError, ValueError, KeyError, TypeError):
            return 0

    def calls_today(self, today: Optional[date] = None) -> int:
        return self._load(today or datetime.now(timezone.utc).date())

    @property
    def allowed(self) -> int:
        return int(self.daily_limit * self.stop_fraction)

    def can_call(self, today: Optional[date] = None) -> bool:
        return self.calls_today(today) < self.allowed

    def record(self, today: Optional[date] = None) -> None:
        today = today or datetime.now(timezone.utc).date()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps({"date": today.isoformat(), "calls": self._load(today) + 1}),
                             encoding="utf-8")


# ---------------------------------------------------------------------------
# HTTP client
# ---------------------------------------------------------------------------
class ApiFootballClient:
    def __init__(self, api_key: str, base_url: str, budget: BudgetTracker, session: Any = None, timeout: int = 20):
        if session is None:
            import requests
            session = requests.Session()
        self._key, self.base_url, self.budget, self.session, self.timeout = api_key, base_url.rstrip("/"), budget, session, timeout
        self.calls_this_run = 0

    def get(self, endpoint: str, params: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        if not self.budget.can_call():
            raise BudgetExceeded(f"daily budget reached ({self.budget.allowed} of {self.budget.daily_limit} calls)")
        resp = self.session.get(f"{self.base_url}/{endpoint.lstrip('/')}", params=params or {},
                                headers={"x-apisports-key": self._key}, timeout=self.timeout)
        self.budget.record()                      # a failed call still counts against the quota
        self.calls_this_run += 1
        if resp.status_code != 200:
            raise ApiFootballError(f"{endpoint}: HTTP {resp.status_code}")
        data = resp.json()
        errors = data.get("errors")
        if errors:                                # API-Football returns [] when fine, {..} when not
            raise ApiFootballError(f"{endpoint}: {errors}")
        return data

    def get_all_pages(self, endpoint: str, params: dict[str, Any]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        page = 1
        while True:
            data = self.get(endpoint, {**params, "page": page})
            out.extend(data.get("response") or [])
            total = int((data.get("paging") or {}).get("total") or 1)
            if page >= total:
                return out
            page += 1


# ---------------------------------------------------------------------------
# Club name -> club id
# ---------------------------------------------------------------------------
def _name_key(name: Any) -> str:
    s = str(name or "").lower().replace("&", " and ")
    s = re.sub(r"[^a-z0-9 ]+", " ", s)
    s = re.sub(r"\b(fc|afc)\b", " ", s)
    return re.sub(r"\s+", " ", s).strip()


class ClubResolver:
    def __init__(self, clubs: list[dict[str, Any]]):
        self._map: dict[str, str] = {}
        for c in clubs:
            for n in [c["name"], *c.get("aliases", [])]:
                self._map[_name_key(n)] = c["id"]

    @classmethod
    def from_config(cls, config_dir: Path | str | None = None) -> "ClubResolver":
        return cls(load_clubs(config_dir))

    def resolve(self, name: Any) -> Optional[str]:
        return self._map.get(_name_key(name))


# ---------------------------------------------------------------------------
# Parsing (pure functions, tested with canned payloads)
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ParsedInjury:
    club_id: str
    team_name: str
    provider_player_id: str
    norm: NormInjury


@dataclass
class ParseResult:
    injuries: list[ParsedInjury] = field(default_factory=list)
    unknown_clubs: set[str] = field(default_factory=set)
    needs_review: list[str] = field(default_factory=list)


def _fixture_dt(fixture: dict[str, Any]) -> Optional[datetime]:
    ts = fixture.get("timestamp")
    if isinstance(ts, (int, float)) and ts > 0:
        return datetime.fromtimestamp(ts, tz=timezone.utc)
    return parse_datetime(fixture.get("date"))


def parse_injuries(payload: dict[str, Any], *, as_of: datetime, resolver: ClubResolver, source_url: str,
                   max_age_days: int = 3, gap_days: int = 21) -> ParseResult:
    """Collapse per-fixture entries into one current injury per player."""
    result = ParseResult()
    groups: dict[str, list[tuple[datetime, dict[str, Any]]]] = {}
    for entry in payload.get("response") or []:
        player, fixture = entry.get("player") or {}, entry.get("fixture") or {}
        dt = _fixture_dt(fixture)
        if player.get("id") is None or dt is None:
            continue
        groups.setdefault(str(player["id"]), []).append((dt, entry))

    cutoff = as_of - timedelta(days=max_age_days)
    for pid, items in groups.items():
        items.sort(key=lambda x: x[0])
        latest_dt, latest = items[-1]
        if latest_dt < cutoff:
            continue                              # last listed for an old fixture: no longer reported
        player, team = latest["player"], latest.get("team") or {}
        club_id = resolver.resolve(team.get("name"))
        if club_id is None:
            result.unknown_clubs.add(str(team.get("name")))
            continue
        reason_key = clean_text(player.get("reason"))
        start = latest_dt
        for dt, e in reversed(items[:-1]):        # walk back through the unbroken run of this reason
            if clean_text(e["player"].get("reason")) != reason_key or (start - dt).days > gap_days:
                break
            start = dt
        status = normalise_status(player.get("type"))
        if status.status is None:
            result.needs_review.append(f"{player.get('name')}: {status.reason}")
            continue
        result.injuries.append(ParsedInjury(club_id, str(team.get("name")), pid, NormInjury(
            provider=PROVIDER, provider_player_id=pid, provider_club_id=str(team.get("id")),
            player_name=str(player.get("name") or "").strip(), injury_type_raw=str(player.get("reason") or ""),
            status=status.status, reported_at=as_of, source_name=SOURCE_NAME, source_url=source_url,
            start_date=start.date())))
    result.injuries.sort(key=lambda p: (p.club_id, p.norm.player_name))
    return result


def parse_teams(payload: dict[str, Any], resolver: ClubResolver) -> dict[str, str]:
    """provider team id -> club id (unknown teams are left out)."""
    out: dict[str, str] = {}
    for item in payload.get("response") or []:
        t = item.get("team") or {}
        cid = resolver.resolve(t.get("name"))
        if cid and t.get("id") is not None:
            out[str(t["id"])] = cid
    return out


def parse_team_stats(payload: dict[str, Any]) -> Optional[tuple[int, int]]:
    """(matches_played, goals_for) from /teams/statistics, or None if the shape is unexpected."""
    r = payload.get("response")
    if not isinstance(r, dict):
        return None
    try:
        played = int(r["fixtures"]["played"]["total"] or 0)
        goals = int(r["goals"]["for"]["total"]["total"] or 0)
    except (KeyError, TypeError, ValueError):
        return None
    return played, goals


def parse_player_stats(payload: dict[str, Any], league_id: int) -> Optional[dict[str, Any]]:
    """Season totals for one player in one league. Missing numbers count as 0; no match -> None."""
    items = payload.get("response") or []
    if not items:
        return None
    item = items[0]
    minutes = goals = assists = 0
    position = None
    found = False
    for st in item.get("statistics") or []:
        if (st.get("league") or {}).get("id") != league_id:
            continue
        found = True
        minutes += int((st.get("games") or {}).get("minutes") or 0)
        goals += int((st.get("goals") or {}).get("total") or 0)
        assists += int((st.get("goals") or {}).get("assists") or 0)
        position = position or (st.get("games") or {}).get("position")
    if not found:
        return None
    pos = normalise_position(position)
    dob = ((item.get("player") or {}).get("birth") or {}).get("date")
    return {"minutes": minutes, "goals": goals, "assists": assists,
            "position": pos.value if pos else "", "date_of_birth": dob or ""}


# ---------------------------------------------------------------------------
# CSV output. Manual columns (rating etc.) survive refreshes; the feed owns which rows exist.
# ---------------------------------------------------------------------------
def _read_existing(path: Path) -> dict[tuple[str, str], dict[str, str]]:
    if not path.is_file():
        return {}
    with open(path, newline="", encoding="utf-8") as fh:
        return {(r["club"], r["player"].lower()): r for r in csv.DictReader(fh)
                if r.get("club") and not r["club"].startswith("EXAMPLE")}


def write_injuries_csv(path: Path | str, parsed: list[ParsedInjury],
                       stats: Optional[dict[str, dict[str, Any]]] = None) -> int:
    path = Path(path)
    existing = _read_existing(path)
    stats = stats or {}
    rows = []
    for p in parsed:
        n = p.norm
        old = existing.get((p.club_id, n.player_name.lower()), {})
        s = stats.get(p.provider_player_id, {})
        row = {"club": p.club_id, "player": n.player_name, "injury_type": n.injury_type_raw,
               "status": n.status.value}
        for col in ("position", "date_of_birth", "minutes", "goals", "assists"):
            val = s.get(col, "")
            row[col] = str(val) if val != "" else old.get(col, "")      # fresh stats win, else keep old
        row["rating"] = old.get("rating", "")                           # manual only, never overwritten
        row["start_date"] = old.get("start_date") or (n.start_date.isoformat() if n.start_date else "")
        rows.append(row)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=INJURY_COLUMNS)
        w.writeheader()
        w.writerows(rows)
    return len(rows)


def write_team_stats_csv(path: Path | str, stats: dict[str, tuple[int, int]]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["club", "matches_played", "total_goals"])
        for club in sorted(stats):
            w.writerow([club, *stats[club]])


# ---------------------------------------------------------------------------
# Orchestration / CLI
# ---------------------------------------------------------------------------
def run(client: ApiFootballClient, data_dir: Path | str, *, league_id: int, season: int,
        resolver: ClubResolver, with_stats: bool = False, as_of: Optional[datetime] = None,
        log=print) -> dict[str, Any]:
    data_dir = Path(data_dir)
    as_of = as_of or datetime.now(timezone.utc)
    url = f"{client.base_url}/injuries?league={league_id}&season={season}"
    parsed = parse_injuries(client.get("injuries", {"league": league_id, "season": season}),
                            as_of=as_of, resolver=resolver, source_url=url)
    warnings: list[str] = []
    stats: dict[str, dict[str, Any]] = {}

    if with_stats:
        try:
            team_ids = parse_teams(client.get("teams", {"league": league_id, "season": season}), resolver)
            team_stats: dict[str, tuple[int, int]] = {}
            for tid, club in team_ids.items():
                ts = parse_team_stats(client.get("teams/statistics",
                                                 {"league": league_id, "season": season, "team": tid}))
                if ts:
                    team_stats[club] = ts
            if team_stats:
                write_team_stats_csv(data_dir / "team_stats.csv", team_stats)
            for p in parsed.injuries:
                ps = parse_player_stats(client.get("players", {"id": p.provider_player_id, "season": season}), league_id)
                if ps:
                    stats[p.provider_player_id] = ps
        except BudgetExceeded as exc:
            warnings.append(f"stopped early: {exc}. Run again tomorrow to finish the stats.")

    n = write_injuries_csv(data_dir / "injuries.csv", parsed.injuries, stats)
    if parsed.unknown_clubs:
        warnings.append(f"skipped clubs not in clubs.yaml: {sorted(parsed.unknown_clubs)}")
    warnings += [f"needs review: {m}" for m in parsed.needs_review]
    for w in warnings:
        log("WARNING", w)
    log(f"wrote {n} injuries; {client.calls_this_run} API calls this run")
    return {"injuries": n, "calls": client.calls_this_run, "warnings": warnings}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Refresh data/*.csv from API-Football")
    ap.add_argument("--data", default="data")
    ap.add_argument("--with-stats", action="store_true", help="also fetch team and injured-player season stats")
    args = ap.parse_args(argv)
    load_dotenv_if_available()
    s = load_settings()
    cfg = s.providers.get("api_football")
    if not cfg or not cfg.enabled:
        raise SystemExit("api_football is disabled in config/settings.yaml")
    budget = BudgetTracker(Path(args.data) / ".api_usage.json", cfg.daily_limit or 100,
                           s.budget.normal_stop_fraction)
    client = ApiFootballClient(get_secret("API_FOOTBALL_KEY"), cfg.base_url or "https://v3.football.api-sports.io", budget)
    run(client, args.data, league_id=cfg.league_id or 39, season=s.api_football_season,
        resolver=ClubResolver.from_config(), with_stats=args.with_stats)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
