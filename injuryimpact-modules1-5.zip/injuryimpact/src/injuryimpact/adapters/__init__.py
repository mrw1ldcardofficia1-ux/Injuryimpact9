"""Data-provider adapters. They output normalised types and never touch the database."""
