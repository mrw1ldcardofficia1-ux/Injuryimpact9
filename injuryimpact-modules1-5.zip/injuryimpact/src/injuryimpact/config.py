"""Typed configuration loader. Secrets come from environment variables only."""
from __future__ import annotations

import hashlib
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import yaml

DEFAULT_CONFIG_DIR = Path(__file__).resolve().parents[2] / "config"
WEIGHT_KEYS = ("minutes_share", "goal_contribution_share", "replacement_gap", "fixture_difficulty")
STATUS_KEYS = ("out", "doubtful", "returning")


class ConfigError(ValueError):
    """Raised when a config file is missing or invalid."""


class MissingSecretError(RuntimeError):
    """Raised when a required environment variable is not set."""


def get_secret(name: str) -> str:
    """Read an API key from the environment. Never hard-code secrets."""
    value = os.environ.get(name, "").strip()
    if not value:
        raise MissingSecretError(f"Environment variable {name} is not set (see .env.example).")
    return value


def load_dotenv_if_available() -> None:
    try:
        from dotenv import load_dotenv
    except ImportError:  # python-dotenv is optional at runtime
        return
    load_dotenv()


# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ImpactConfig:
    version: str
    fingerprint: str                      # hash of weights.yaml, stored for audit
    weights: dict[str, float]
    default_replacement_gap: float
    neutral_fixture_difficulty: float
    scale_max: float


@dataclass(frozen=True)
class ClubScoreConfig:
    method: str
    status_weights: dict[str, float]
    cap: float


@dataclass(frozen=True)
class ProviderConfig:
    name: str
    enabled: bool
    base_url: Optional[str] = None
    league_id: Optional[int] = None
    daily_limit: Optional[int] = None


@dataclass(frozen=True)
class BudgetConfig:
    normal_stop_fraction: float
    fast_mode_stop_fraction: float


@dataclass(frozen=True)
class SchedulerConfig:
    normal_interval_hours: float
    fast_interval_minutes: float
    press_conference_weekdays: tuple[int, ...]
    fast_mode_endpoints: tuple[str, ...]


@dataclass(frozen=True)
class RecoveryConfig:
    age_threshold: int
    age_multiplier: float
    reinjury_window_days: int
    reinjury_multiplier: float


@dataclass(frozen=True)
class ValidationConfig:
    max_future_start_days: int
    stale_report_days: int


@dataclass(frozen=True)
class Settings:
    season: str
    api_football_season: int
    impact: ImpactConfig
    club: ClubScoreConfig
    providers: dict[str, ProviderConfig]
    budget: BudgetConfig
    scheduler: SchedulerConfig
    recovery: RecoveryConfig
    validation: ValidationConfig

    @property
    def weights_version(self) -> str:
        return f"{self.impact.version}+{self.impact.fingerprint}"


# ---------------------------------------------------------------------------
def _read_yaml(path: Path) -> tuple[dict[str, Any], bytes]:
    if not path.is_file():
        raise ConfigError(f"Config file not found: {path}")
    raw = path.read_bytes()
    data = yaml.safe_load(raw)
    if not isinstance(data, dict):
        raise ConfigError(f"{path.name} must contain a YAML mapping.")
    return data, raw


def _need(d: dict[str, Any], key: str, where: str) -> Any:
    if key not in d:
        raise ConfigError(f"Missing '{key}' in {where}.")
    return d[key]


def _unit(value: Any, name: str) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        raise ConfigError(f"{name} must be a number, got {value!r}.") from None
    if not 0.0 <= v <= 1.0:
        raise ConfigError(f"{name} must be between 0 and 1, got {v}.")
    return v


def _parse_impact(data: dict[str, Any], raw: bytes) -> tuple[ImpactConfig, ClubScoreConfig]:
    impact = _need(data, "impact", "weights.yaml")
    weights_in = _need(impact, "weights", "weights.yaml impact")
    missing = [k for k in WEIGHT_KEYS if k not in weights_in]
    extra = [k for k in weights_in if k not in WEIGHT_KEYS]
    if missing or extra:
        raise ConfigError(f"Impact weights must be exactly {WEIGHT_KEYS}; missing={missing} extra={extra}.")
    weights = {k: _unit(weights_in[k], f"weight {k}") for k in WEIGHT_KEYS}
    if not math.isclose(sum(weights.values()), 1.0, abs_tol=1e-6):
        raise ConfigError(f"Impact weights must sum to 1.0, got {sum(weights.values()):.6f}.")

    defaults = _need(impact, "defaults", "weights.yaml impact")
    scale_max = float(impact.get("scale_max", 10.0))
    if scale_max <= 0:
        raise ConfigError("scale_max must be positive.")

    impact_cfg = ImpactConfig(
        version=str(_need(data, "version", "weights.yaml")),
        fingerprint=hashlib.sha256(raw).hexdigest()[:10],
        weights=weights,
        default_replacement_gap=_unit(_need(defaults, "replacement_gap", "defaults"), "default replacement_gap"),
        neutral_fixture_difficulty=_unit(_need(defaults, "fixture_difficulty", "defaults"), "default fixture_difficulty"),
        scale_max=scale_max,
    )

    club = _need(data, "club", "weights.yaml")
    sw_in = _need(club, "status_weights", "weights.yaml club")
    if set(sw_in) != set(STATUS_KEYS):
        raise ConfigError(f"club.status_weights must have exactly {STATUS_KEYS}.")
    cap = float(club.get("cap", scale_max))
    if not 0 < cap <= scale_max:
        raise ConfigError("club.cap must be in (0, scale_max].")
    club_cfg = ClubScoreConfig(
        method=str(club.get("method", "diminishing_returns")),
        status_weights={k: _unit(sw_in[k], f"status weight {k}") for k in STATUS_KEYS},
        cap=cap,
    )
    return impact_cfg, club_cfg


def load_settings(config_dir: Optional[Path | str] = None) -> Settings:
    base = Path(config_dir or os.environ.get("INJURYIMPACT_CONFIG_DIR") or DEFAULT_CONFIG_DIR)
    weights_data, weights_raw = _read_yaml(base / "weights.yaml")
    s, _ = _read_yaml(base / "settings.yaml")

    impact_cfg, club_cfg = _parse_impact(weights_data, weights_raw)

    providers: dict[str, ProviderConfig] = {}
    for name, p in _need(s, "providers", "settings.yaml").items():
        limit = p.get("daily_limit")
        if limit is not None and int(limit) <= 0:
            raise ConfigError(f"providers.{name}.daily_limit must be positive.")
        providers[name] = ProviderConfig(
            name=name,
            enabled=bool(p.get("enabled", False)),
            base_url=p.get("base_url"),
            league_id=p.get("league_id"),
            daily_limit=int(limit) if limit is not None else None,
        )

    b = _need(s, "budget", "settings.yaml")
    normal = _unit(_need(b, "normal_stop_fraction", "budget"), "budget.normal_stop_fraction")
    fast = _unit(_need(b, "fast_mode_stop_fraction", "budget"), "budget.fast_mode_stop_fraction")
    if not 0 < normal <= fast <= 1:
        raise ConfigError("Budget fractions must satisfy 0 < normal <= fast <= 1.")

    sc = _need(s, "scheduler", "settings.yaml")
    days = tuple(int(d) for d in sc.get("press_conference_weekdays", []))
    if any(d < 0 or d > 6 for d in days):
        raise ConfigError("press_conference_weekdays must be 0-6 (Monday=0).")

    r = _need(s, "recovery", "settings.yaml")
    v = _need(s, "validation", "settings.yaml")

    return Settings(
        season=str(_need(s, "season", "settings.yaml")),
        api_football_season=int(_need(s, "api_football_season", "settings.yaml")),
        impact=impact_cfg,
        club=club_cfg,
        providers=providers,
        budget=BudgetConfig(normal, fast),
        scheduler=SchedulerConfig(
            normal_interval_hours=float(sc["normal_interval_hours"]),
            fast_interval_minutes=float(sc["fast_interval_minutes"]),
            press_conference_weekdays=days,
            fast_mode_endpoints=tuple(sc.get("fast_mode_endpoints", [])),
        ),
        recovery=RecoveryConfig(
            age_threshold=int(r["age_threshold"]),
            age_multiplier=float(r["age_multiplier"]),
            reinjury_window_days=int(r["reinjury_window_days"]),
            reinjury_multiplier=float(r["reinjury_multiplier"]),
        ),
        validation=ValidationConfig(
            max_future_start_days=int(v["max_future_start_days"]),
            stale_report_days=int(v["stale_report_days"]),
        ),
    )


def load_aliases(config_dir: Optional[Path | str] = None) -> dict[str, list[str]]:
    base = Path(config_dir or os.environ.get("INJURYIMPACT_CONFIG_DIR") or DEFAULT_CONFIG_DIR)
    data, _ = _read_yaml(base / "injury_aliases.yaml")
    return {str(k): [str(a) for a in v] for k, v in data.items()}
